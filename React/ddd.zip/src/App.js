import React, { useState, useEffect } from 'react';

const ParkingTitleApp = () => {
  const [parkingTitle, setParkingTitle] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchParkingTitle = async (pName) => {
      try {
        const response = await fetch('https://api.aitnt.ca/api/Home/ParkingTitle?title='+pName);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setParkingTitle(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    var p1 = 'on_cc_p01';  // it can be initial by user per as selcting a parking from map
    fetchParkingTitle(p1);

  }, []);

  return (
    <div>
      <h2>Parking Information</h2>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      {parkingTitle && (
        <div>
          <p>{JSON.stringify(parkingTitle)}</p> {/* Display the parking data */}
        </div>
      )}
    </div>
  );
};

export default ParkingTitleApp;
